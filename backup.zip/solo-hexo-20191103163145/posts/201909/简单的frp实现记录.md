title: 简单的frp实现 记录
date: '2019-09-02 16:34:02'
updated: '2019-09-02 16:34:02'
tags: [frp, linux]
permalink: /articles/2019/09/02/1567413241983.html
---
1.去[](https://)https://github.com/fatedier/frp/releases   下载最新版本（C/S）
2.配置server端的  frps.ini
```
[common]
bind_port = 7000
vhost_http_port = 8080
dashboard_port = 7500
# dashboard 用户名密码，默认都为 admin
dashboard_user = admin
dashboard_pwd = admin
```
3.启动server端
```
./frps -c ./frps.ini
```
4.配置客户端
```
[common]
server_addr = 118.25.46.145
server_port = 7000

[web]
type = http
local_port = 8080
custom_domains = zach.frp.chinazach.com

```
5.启动客户端
```
frpc -c ./frpc.ini
```
6.访问http://chinazach.com:7500/可以查看dashboard