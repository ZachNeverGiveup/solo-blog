title: '解决com.mysql.jdbc.PacketTooBigException: Packet for query is too large (3158064）问题'
date: '2019-09-16 20:24:54'
updated: '2019-09-16 20:24:54'
tags: [Solo, mysql, 建站]
permalink: /articles/2019/09/16/1568636694880.html
---
回到家发现网站404了。。
![image.png](https://img.hacpai.com/file/2019/09/image-c8c33a6c.png)

查了半天，重新拉镜像，重启服务，打印日志发现报了下面的错误：


![image.png](https://img.hacpai.com/file/2019/09/image-ecb0e115.png)


**MySQL的max_allowed_packet 设置过小导致记录写入失败。**

mysql根据配置文件会限制server接受的数据包大小。

有时候大的插入和更新会受max_allowed_packet 参数限制，导致写入或者更新失败。

于是进入MySQL修改了这个值。

参考文章：[# 解决com.mysql.jdbc.PacketTooBigException: Packet for query is too large (3158064）问题](https://blog.csdn.net/fly0744/article/details/13623079)

