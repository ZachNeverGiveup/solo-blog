title: 添加https证书说明
date: '2019-10-28 13:43:47'
updated: '2019-10-28 13:44:54'
tags: [docker, linux, nginx, 命令]
permalink: /articles/2019/10/28/1572241427006.html
---
使用**acme.sh**来生成证书。
参考网址：[acme.sh安装文档](https://github.com/Neilpang/acme.sh/wiki/%E8%AF%B4%E6%98%8E)

**1.安装acme.sh**
```
curl  https://get.acme.sh | sh
```
**2.生成证书**
**acme.sh** 实现了 **acme** 协议支持的所有验证协议. 一般有两种方式验证: http 和 dns 验证.
此处采用dns的方式验证。
dns 方式的真正强大之处在于可以使用域名解析商提供的 api 自动添加 txt 记录完成验证.
**acme.sh** 目前支持 cloudflare, dnspod, cloudxns, godaddy 以及 ovh 等数十种解析商的自动集成.
此处采用阿里云的解析。
先去[https://ak-console.aliyun.com/#/accesskey](https://ak-console.aliyun.com/#/accesskey)获取秘钥。
然后输入以下命令：
```
export Ali_Key="******"
export Ali_Secret="***************************"
```
然后输入命令来颁发证书
```
acme.sh --issue --dns dns_ali -d *.chinazach.com
```
**3.拷贝证书到nginx的目录**
前面证书生成以后, 接下来需要把证书 copy 到真正需要用它的地方.

注意, 默认生成的证书都放在安装目录下: `~/.acme.sh/`, 请不要直接使用此目录下的文件, 例如: 不要直接让 nginx/apache 的配置文件使用这下面的文件. 这里面的文件都是内部使用, 而且目录结构可能会变化.

正确的使用方法是使用 `--installcert` 命令,并指定目标位置, 然后证书文件会被copy到相应的位置,
```
acme.sh  --installcert  -d  *.chinazach.com   \
        --key-file   /root/nginx/conf/*.chinazach.com.key \
        --fullchain-file /root/nginx/conf/fullchain.cer \
        --reloadcmd  "service nginx force-reload"
```
由于我的nginx是跑在docker容器里的，所以要进入到容器内部 reload nginx ：
```
docker exec -it nginx nginx -s reload
```
这样证书就生成成功了。使用这种方式生成证书是会自动更新的（未验证，等到2020年1月26日验证）。
![image.png](https://img.hacpai.com/file/2019/10/image-b54fb09d.png)

