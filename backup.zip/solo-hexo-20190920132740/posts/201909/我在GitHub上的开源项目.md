title: 我在 GitHub 上的开源项目
date: '2019-09-16 12:17:47'
updated: '2019-09-16 12:17:47'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [ZachNeverGiveup.github.io](https://github.com/ZachNeverGiveup/ZachNeverGiveup.github.io) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/ZachNeverGiveup/ZachNeverGiveup.github.io/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ZachNeverGiveup/ZachNeverGiveup.github.io/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ZachNeverGiveup/ZachNeverGiveup.github.io/network/members "分叉数")</span>





---

### 2. [zachweb](https://github.com/ZachNeverGiveup/zachweb) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ZachNeverGiveup/zachweb/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ZachNeverGiveup/zachweb/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ZachNeverGiveup/zachweb/network/members "分叉数")</span>

毕设后端工程



---

### 3. [work1_Zach](https://github.com/ZachNeverGiveup/work1_Zach) <kbd title="主要编程语言">CSS</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ZachNeverGiveup/work1_Zach/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ZachNeverGiveup/work1_Zach/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ZachNeverGiveup/work1_Zach/network/members "分叉数")</span>





---

### 4. [ConnextPro](https://github.com/ZachNeverGiveup/ConnextPro) <kbd title="主要编程语言">CSS</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/ZachNeverGiveup/ConnextPro/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/ZachNeverGiveup/ConnextPro/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/ZachNeverGiveup/ConnextPro/network/members "分叉数")</span>



