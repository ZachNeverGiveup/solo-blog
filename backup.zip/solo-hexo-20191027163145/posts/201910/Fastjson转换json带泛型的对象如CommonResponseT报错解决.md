title: Fastjson转换json，带泛型的对象，如CommonResponse<T>,报错解决
date: '2019-10-11 17:09:22'
updated: '2019-10-11 17:09:22'
tags: [Java]
permalink: /articles/2019/10/11/1570784962461.html
---
1. 问题出现
在项目中遇到
```
CommonResponse commonResponse = JSONObject.parseObject(str,CommonResponse.class);
```
转换json对象的问题，此时可以正确的转换成CommonResponse对象。
但是，当遇到泛型CommonResponse<T>时，如下
```
CommonResponse<T> commonResponse = JSONObject.parseObject(str,CommonResponse<T>.class);
```
就不会正确的转换，转换之后的 commonResponse 里面的T不是T对象，而是一个JSONObject。

---
2.问题解决

fastjson除了上面的方法外,还重载了一个方法

```
public static <T> T parseObject(String text, TypeReference<T> type, Feature... features){}
```

就是这个TypeReference,修改后代码:
```
CommonResponse<T> commonResponse = JSONObject.parseObject(str,new  TypeReference<CommonResponse<T>>(){});
```
 这个时候，这里转换后的 commonResponse 里面的T对象就是一个正确的JavaBean了，而不是一个JSONObject对象。
