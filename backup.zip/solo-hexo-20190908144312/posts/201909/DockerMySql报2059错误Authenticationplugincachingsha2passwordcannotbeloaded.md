title: 'Docker MySql报2059错误: Authentication plugin ''caching_sha2_password'' cannot
  be loaded'
date: '2019-09-02 17:44:24'
updated: '2019-09-06 17:40:07'
tags: [docker, linux]
permalink: /articles/2019/09/02/1567417464250.html
---
```
ALTER USER 'root' IDENTIFIED WITH mysql_native_password BY '123456';
```


[](https://)https://blog.csdn.net/y472360651/article/details/95047413
