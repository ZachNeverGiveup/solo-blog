title: 通过git bash scp命令向linux服务器上传文件
date: '2019-09-11 14:17:38'
updated: '2019-09-11 14:17:38'
tags: [linux, 命令]
permalink: /articles/2019/09/11/1568182658711.html
---
```
scp k8s.1-14-1.tar.gz root@118.25.46.145:/etc/ansible/down/
```
![image.png](https://img.hacpai.com/file/2019/09/image-ce7d1d48.png)

